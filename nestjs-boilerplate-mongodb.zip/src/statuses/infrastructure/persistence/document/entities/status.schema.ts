export class StatusSchema {
  _id: string;

  name?: string;
}
