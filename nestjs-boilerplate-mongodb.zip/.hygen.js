module.exports = {
  templates: `${__dirname}/.hygen`,
};
